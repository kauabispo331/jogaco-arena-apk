# Jogaço Arena APK

APK Android do jogo Jogaço Arena. É um jogo web HTML5 empacotado em um WebView nativo, sem dependências C++ ou NDK.

Abra a pasta no Android Studio ou use o workflow em `.github/workflows/build-apk.yml`.
